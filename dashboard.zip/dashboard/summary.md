# 📊 Global Sales Performance Dashboard (2011–2014)

## Overview
Analyzes global sales trends, customer performance, and category breakdowns over four years.

## Tools Used
- Power BI
- Excel

## Key Metrics
- Total Sales: 3.58M
- Profit Margin: 12.16%
- Quantity Sold: 41K

## Insights
- Sales grew 24% YoY, but profit margin dropped 1%
- Technology is the top-performing category
- Standard shipping accounts for 62% of deliveries

## Business Impact
Helps identify high-value customers, optimize category focus, and improve shipping strategy.
